import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.{Row, functions}
import org.apache.spark.sql.functions._
import practica.ejercicio3
import utils.TestInit

import scala.collection.mutable

class practicaTest extends TestInit  {

  import spark.implicits._

  "ejercicio1"  should "Primer Ejercicio Ejecutado" in {



    val estudiantes = Seq(
      ("Juan", 20, 9),
      ("María", 22, 8),
      ("Pedro", 21, 7),
      ("Ana", 23, 10),
      ("Luis", 22, 6)
    ).toDF("nombre", "edad", "calificacion")


    val estudiantesAltaCalificacion = estudiantes.filter($"calificacion" > 8)


    assert(estudiantesAltaCalificacion.count() == 2)



    val estudiantesOrdenados = estudiantes.select("nombre", "calificacion")
      .orderBy($"calificacion".desc)


    val estudiantesOrdenadosArray = estudiantesOrdenados.collect().map(row => (row.getAs[String]("nombre"), row.getAs[Int]("calificacion")))
    assert(estudiantesOrdenadosArray.sameElements(Array(("Ana", 10), ("Juan", 9), ("María", 8), ("Pedro", 7), ("Luis", 6))))
    practica.ejercicio1()
  }


  "ejercicio2"  should "Determina si un numero es par o impar" in {


      val estudiantes = Seq(
        ("Juan", 20, 9),
        ("María", 22, 8),
        ("Pedro", 21, 7),
        ("Ana", 23, 10),
        ("Luis", 22, 6)
      ).toDF("nombre", "edad", "calificacion")


    val esParOImpar: UserDefinedFunction = udf((numero: Int) => {
      if (numero % 2 == 0) "par" else "impar"
    })


      val estudiantesConParidad = estudiantes
        .withColumn("paridad", esParOImpar(col("edad")))
        .select("nombre", "edad", "paridad")


      val resultado = estudiantesConParidad.collect()


      assert(resultado(0).getAs[String]("paridad") == "par")  // Juan, 20 es par
      assert(resultado(1).getAs[String]("paridad") == "par")  // María, 22 es par
      assert(resultado(2).getAs[String]("paridad") == "impar")  // Pedro, 21 es impar
      assert(resultado(3).getAs[String]("paridad") == "impar")  // Ana, 23 es impar
      assert(resultado(4).getAs[String]("paridad") == "par")  // Luis, 22 es par
    practica.ejercicio2()
    }


  "ejercicio3" should "calcular el promedio de calificaciones correctamente" in {


    import spark.implicits._


    val resultadosEsperados = Seq(
      (1, "Juan", 8.5),   // (9+8)/2 = 8.5
      (2, "María", 8.0),  // (7+9)/2 = 8.0
      (3, "Pedro", 6.5),  // (6+7)/2 = 6.5
      (4, "Ana", 9.0),    // (8+10)/2 = 9.0
      (5, "Luis", 5.5),   // (5+6)/2 = 5.5
      (6, "Carlos", 8.5), // (9+8)/2 = 8.5
      (7, "Sofia", 9.5),  // (10+9)/2 = 9.5
      (8, "Marta", 7.0)   // (7+7)/2 = 7.0
    ).toDF("id", "nombre", "promedio_calificacion")


    val resultOrdered = resultadosEsperados.orderBy("id").collect()
    val expectedOrdered = resultadosEsperados.orderBy("id").collect()


    assert(resultOrdered.sameElements(expectedOrdered))
    practica.ejercicio3()
  }

  "ejercicio4" should "cuenta el numero de veces que se repite una palabra" in {

    val palabras = List(
      "Pikachu", "Charmander", "Bulbasaur", "Squirtle", "Jigglypuff",
      "Pidgey", "Rattata", "Meowth", "Psyduck", "Machop",
      "Onix", "Zubat", "Geodude", "Eevee", "Mankey",
      "Poliwag", "Magnemite", "Shellder", "Gastly", "Drowzee",
      "Vileplume", "Gloom", "Raichu", "Charizard", "Venusaur",
      "Blastoise", "Pidgeot", "Alakazam", "Machoke", "Muk",
      "Dugtrio", "Seaking", "Starmie", "Butterfree", "Beedrill",
      "Weedle", "Nidoran♀", "Nidoran♂", "Nidoking", "Nidoqueen",
      "Sandshrew", "Politoed", "Kingdra", "Pineco", "Forretress",
      "Surskit", "Masquline", "Zangoose", "Seviper", "Swablu",
      "Altaria", "Shuppet", "Bannet", "Corphish", "Crawdaunt",
      "Feebas", "Milotic", "Beldum", "Metagross", "Tropius",
      "Ralts", "Kirlia", "Gardevoir", "Gulpin", "Swalot",
      "Trapinch", "Vibrava", "Flygon", "Castform", "Shroomish",
      "Breloom", "Slakoth", "Vigoroth", "Slaking", "Beldum",
      "Registeel", "Regice", "Regirock", "Jirachi", "Deoxys",
      "Torterra", "Infernape", "Empoleon", "Staraptor", "Luxray",
      "Machamp", "Garchomp", "Gabite", "Drifloon", "Drifblim",
      "Mimikyu", "Salandit", "Salazzle", "Zorua", "Zoroark",
      "Rowlet", "Dartrix", "Decidueye", "Litten", "Torracat",
      "Incineroar", "Popplio", "Brionne", "Primarina", "Sobble",
      "Drizzile", "Inteleon", "Grookey", "Thwackey", "Rillaboom"
    )


    val palabrasRDD = spark.sparkContext.parallelize(palabras)


    val df = palabrasRDD.toDF("palabra")


    val conteoPalabrasDF = df.groupBy("palabra")
      .agg(functions.count("palabra").alias("conteo"))
      .orderBy(functions.col("conteo").desc)


    val palabrasDiferentes = conteoPalabrasDF.count()
    assert(palabrasDiferentes > 0, "Debe haber palabras en el DataFrame")


    val resultados = conteoPalabrasDF.collect()


    resultados.take(5).foreach {
      case Row(palabra: String, conteo: Long) =>
        println(s"Palabra: $palabra, Conteo: $conteo")
    }


    assert(resultados.exists(row => row.getString(0) == "Beldum"), "Debe contener la palabra 'Beldum'")
    assert(resultados.exists(row => row.getString(0) == "Pikachu"), "Debe contener la palabra 'Pikachu'")


    val totalOcurrencias = resultados.map(_.getLong(1)).sum
    assert(totalOcurrencias == palabras.length, s"El número total de ocurrencias debe ser igual a la longitud de la lista: $totalOcurrencias")
  }

  "ejercicio5" should "calcula el ingreso total (cantidad * precio_unitario) por producto" in {

    // Definir la clase Venta dentro del test
    case class Venta(id_venta: Int, id_producto: Int, cantidad: Int, precio_unitario: Double)

    // Datos de ventas simuladas
    val ventas = Seq(
      Venta(1, 101, 5, 10.0),  // Producto 101, 5 unidades, precio 10.0
      Venta(2, 102, 2, 20.0),  // Producto 102, 2 unidades, precio 20.0
      Venta(3, 101, 3, 10.0)   // Producto 101, 3 unidades, precio 10.0
    )

    // Mapa para almacenar los ingresos por producto
    val ingresosPorProducto = mutable.Map[Int, Double]()

    // Calcular ingresos por producto
    ventas.foreach { venta =>
      val ingresoTotal = venta.cantidad * venta.precio_unitario
      ingresosPorProducto(venta.id_producto) = ingresosPorProducto.getOrElse(venta.id_producto, 0.0) + ingresoTotal
    }

    // Verificar los ingresos calculados con assert
    assert(ingresosPorProducto(101) == 80.0, "El ingreso total para el producto 101 es incorrecto")
    assert(ingresosPorProducto(102) == 40.0, "El ingreso total para el producto 102 es incorrecto")
  }
}