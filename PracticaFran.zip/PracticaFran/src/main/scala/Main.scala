
object Main {
  def main(args: Array[String]): Unit = {
    practica.ejercicio1()
    practica.ejercicio2()
    practica.ejercicio3()
    practica.ejercicio4()
    practica.ejercicio5()
  }
}
