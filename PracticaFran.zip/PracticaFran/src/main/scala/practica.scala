
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession, functions}
import org.apache.spark.sql.functions._
import practica.spark

object practica {

  val spark: SparkSession = SparkSession.builder()
    .appName("Pratica_Scala")
    .master("local[*]")
    .getOrCreate()


  /** Ejercicio 1: Crear un DataFrame y realizar operaciones básicas
   * Pregunta: Crea un DataFrame a partir de una secuencia de tuplas que contenga información sobre
   * e  studiantes (nombre, edad, calificación).
   * R  ealiza las siguientes operaciones:
   *
   * M  uestra el esquema del DataFrame.
   * F  iltra los estudiantes con una calificación mayor a 8.
   * S  elecciona los nombres de los estudiantes y ordénalos por calificación de forma descendente.
   */
  def ejercicio1(): Unit = {

    import org.apache.spark.rdd
    import org.apache.spark.sql.{DataFrame, SparkSession}
    import org.apache.spark.sql.functions._
    import org.apache.spark.sql.types._


    import spark.implicits._


    val estudiantes = Seq(
      ("Juan", 20, 9),
      ("María", 22, 8),
      ("Pedro", 21, 7),
      ("Ana", 23, 10),
      ("Luis", 22, 6)
    ).toDF("nombre", "edad", "calificacion")


    estudiantes.show()
    println("Esquema del DataFrame:")


    val estudiantesAltaCalificacion = estudiantes.filter($"calificacion" > 8)

    println("Estudiantes con calificación mayor a 8:")
    estudiantesAltaCalificacion.show()


    val estudiantesOrdenados = estudiantes.select("nombre", "calificacion")
      .orderBy($"calificacion".desc)

    println("Nombres de estudiantes ordenados por calificación (descendente):")
    estudiantesOrdenados.show()
  }


  /**
   * E  jercicio 2: UDF (User Defined Function)
   * P  regunta: Define una función que determine si un número es par o impar.
   * A  plica esta función a una columna de un DataFrame que contenga una lista de números.
   */

  def ejercicio2(): Unit = {

    import org.apache.spark.sql.expressions.UserDefinedFunction
    import org.apache.spark.rdd
    import org.apache.spark.sql.{DataFrame, SparkSession}
    import org.apache.spark.sql.functions._
    import org.apache.spark.sql.types._

    import spark.implicits._

    val estudiantes = Seq(
      ("Juan", 20, 9),
      ("María", 22, 8),
      ("Pedro", 21, 7),
      ("Ana", 23, 10),
      ("Luis", 22, 6)
    ).toDF("nombre", "edad", "calificacion")


    val esParOImpar: UserDefinedFunction = udf((numero: Int) => {
      if (numero % 2 == 0) "par" else "impar"
    })


    val estudiantesConParidad = estudiantes
      .withColumn("paridad", esParOImpar(col("edad"))) // Aplicamos la UDF a la columna "edad"
      .select("nombre", "edad", "paridad") // Seleccionamos solo las columnas deseadas


    estudiantesConParidad.show()

  }

  /**
   * E  jercicio 3: Joins y agregaciones
   * P  regunta: Dado dos DataFrames,
   * u  no con información de estudiantes (id, nombre)
   * y   otro con calificaciones (id_estudiante, asignatura, calificacion),
   * r  ealiza un join entre ellos y calcula el promedio de calificaciones por estudiante.
   */


  def ejercicio3(): Unit = {
    import org.apache.spark.sql.{DataFrame, SparkSession}
    import org.apache.spark.sql.functions._ // Importamos todas las funciones de Spark
    import spark.implicits._

    val estudiantes = Seq(
      (1, "Juan"),
      (2, "María"),
      (3, "Pedro"),
      (4, "Ana"),
      (5, "Luis"),
      (6, "Carlos"),
      (7, "Sofia"),
      (8, "Marta")
    ).toDF("id", "nombre")


    estudiantes.show()


    val calificaciones = Seq(
      (1, "Lenguaje", 9),
      (1, "Programación", 8),
      (2, "Lenguaje", 7),
      (2, "Programación", 9),
      (3, "Lenguaje", 6),
      (3, "Programación", 7),
      (4, "Lenguaje", 8),
      (4, "Programación", 10),
      (5, "Lenguaje", 5),
      (5, "Programación", 6),
      (6, "Lenguaje", 9),
      (6, "Programación", 8),
      (7, "Lenguaje", 10),
      (7, "Programación", 9),
      (8, "Lenguaje", 7),
      (8, "Programación", 7)
    ).toDF("id_estudiante", "asignatura", "calificacion")


    calificaciones.show()


    val estudiantesConCalificaciones = estudiantes
      .join(calificaciones, estudiantes("id") === calificaciones("id_estudiante"))
      .drop("id_estudiante") // Eliminar la columna redundante


    val promedioAsignaturas = estudiantesConCalificaciones
      .groupBy("id", "nombre") // Agrupar por estudiante
      .agg(avg("calificacion").alias("promedio_calificacion")) // Promedio de calificaciones


    promedioAsignaturas.show()
  }


  /**
   *
   Ej ercicio 4: Uso de RDDs* Pr egunta: Crea un RDD a partir de una lista de palabras y cuenta la cantidad de ocurrencias de cada palabra.
*/
  import org.apache.spark.SparkContext
  import org.apache.spark.SparkConf

  def ejercicio4(): Unit = {

    val sc = spark.sparkContext


    val palabras = List(
      "Pikachu", "Charmander", "Bulbasaur", "Squirtle", "Jigglypuff",
      "Pidgey", "Rattata", "Meowth", "Psyduck", "Machop",
      "Onix", "Zubat", "Geodude", "Eevee", "Mankey",
      "Poliwag", "Magnemite", "Shellder", "Gastly", "Drowzee",
      "Vileplume", "Gloom", "Raichu", "Charizard", "Venusaur",
      "Blastoise", "Pidgeot", "Alakazam", "Machoke", "Muk",
      "Dugtrio", "Seaking", "Starmie", "Butterfree", "Beedrill",
      "Weedle", "Nidoran♀", "Nidoran♂", "Nidoking", "Nidoqueen",
      "Sandshrew", "Politoed", "Kingdra", "Pineco", "Forretress",
      "Surskit", "Masquline", "Zangoose", "Seviper", "Swablu",
      "Altaria", "Shuppet", "Bannet", "Corphish", "Crawdaunt",
      "Feebas", "Milotic", "Beldum", "Metagross", "Tropius",
      "Ralts", "Kirlia", "Gardevoir", "Gulpin", "Swalot",
      "Trapinch", "Vibrava", "Flygon", "Castform", "Shroomish",
      "Breloom", "Slakoth", "Vigoroth", "Slaking", "Beldum",
      "Registeel", "Regice", "Regirock", "Jirachi", "Deoxys",
      "Torterra", "Infernape", "Empoleon", "Staraptor", "Luxray",
      "Machamp", "Garchomp", "Gabite", "Drifloon", "Drifblim",
      "Mimikyu", "Salandit", "Salazzle", "Zorua", "Zoroark",
      "Rowlet", "Dartrix", "Decidueye", "Litten", "Torracat",
      "Incineroar", "Popplio", "Brionne", "Primarina", "Sobble",
      "Drizzile", "Inteleon", "Grookey", "Thwackey", "Rillaboom"
    )

    val palabrasRDD = sc.parallelize(palabras)

    import spark.implicits._
    val df = palabrasRDD.toDF("palabra")

    val conteoPalabrasDF = df.groupBy("palabra")
      .agg(functions.count("palabra").alias("conteo"))
      .orderBy(functions.col("conteo").desc)

    conteoPalabrasDF.show()



  }

  /**
   *E jercicio 5: Procesamiento de archivos
   *P re gunta: Carga un archivo CSV que contenga información sobre
   *v en tas (id_venta, id_producto, cantidad, precio_unitario)
   *y  c alcula el ingreso total (cantidad * precio_unitario) por producto.
   */

  def ejercicio5(): Unit = {

    import com.github.tototoshi.csv._
    import scala.collection.mutable
    import spark.implicits._

    case class Venta(id_venta: Int, id_producto: Int, cantidad: Int, precio_unitario: Double)


    val reader = CSVReader.open(new java.io.File("C:\\Users\\franc\\Desktop\\Procesamiento Big Data\\PracticaFran\\src\\test\\resources\\ventas.csv"))

    val ventas = reader.allWithHeaders().map { row =>
      Venta(
        id_venta = row("id_venta").toInt,
        id_producto = row("id_producto").toInt,
        cantidad = row("cantidad").toInt,
        precio_unitario = row("precio_unitario").toDouble
      )
    }


    val ingresosPorProducto = mutable.Map[Int, Double]()


    ventas.foreach { venta =>
      val ingresoTotal = venta.cantidad * venta.precio_unitario
      ingresosPorProducto(venta.id_producto) = ingresosPorProducto.getOrElse(venta.id_producto, 0.0) + ingresoTotal
    }


    ingresosPorProducto.foreach { case (idProducto, ingresoTotal) =>
      println(s"Producto ID: $idProducto - Ingreso Total: $ingresoTotal")
    }


    reader.close()
  }


}